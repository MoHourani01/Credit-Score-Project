import requests

url = 'http://localhost:8000/predict_api'
r = requests.post(url,json={'Annual_Income': 19114.12, 'Num_Bank_Accounts' : 3.0, 'Num_Credit_Card' : 4.0, 'Interest_Rate' : 3.0, 'Num_of_Loan' : 4.0, 
'Delay_from_due_date' : 6.0, 'Num_of_Delayed_Payment' : 4.0, 'Changed_Credit_Limit' : 11.27, 'Num_Credit_Inquiries' : 4.0, 'Outstanding_Debt' : 809.98, 
'Credit_History_Age' : 269.0, 'Payment_of_Min_Amount' : 2.0, 'Amount_invested_monthly' : 21.465380, 'Monthly_Balance' : 341.489231, 'delay_by_customer_mean' : 4.25,
'monthlyBalance_by_customer_mean' : 304.555294 })

print(r.json())