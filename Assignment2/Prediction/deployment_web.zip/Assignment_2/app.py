import numpy as np
from flask import Flask, request, jsonify, render_template
import pickle

app = Flask(__name__, static_folder="static")
scale= pickle.load(open('final_scale.pkl', 'rb'))
model = pickle.load(open('final_model.pkl', 'rb'))

@app.route('/')
def home():
    return render_template('main.html')
# if __name__=='__main__':
#     app.run()
@app.route("/static")
def static_files():
    return app.send_static_file('style.css')
@app.route('/predict',methods=['POST'])
def predict():
    '''
    For rendering results on HTML GUI
    '''
    int_features = [int(x) for x in request.form.values()]
    final_features = [np.array(int_features)]
    X_test_scale=scale.transform(final_features)
    prediction = model.predict(X_test_scale)
    prediction = prediction[0]

    if prediction == 0:
        output = 'Poor'
    elif prediction == 1:
        output = 'Standard'
    else:
        output = 'Good'

    return render_template('main.html', prediction_text='The Credit Score is  {}'.format(output))

@app.route('/predict_api',methods=['POST'])
def predict_api():
    '''
    For direct API calls trought request
    '''
    data = request.get_json(force=True)
    prediction = model.predict([np.array(list(data.values()))])

    output = prediction[0]
    return jsonify(output)

if __name__ == "__main__":
    app.run(debug=True)